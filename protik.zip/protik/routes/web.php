<?php

Route::get('/', 'FrontendConrtoller@index');
Route::get('contact', 'FrontendConrtoller@contact');
Route::get('about', 'FrontendConrtoller@about');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/add/mamber/view', 'MamberController@addmamberview');
Route::post('/add/mamber/insert', 'MamberController@addmamberinsert');



