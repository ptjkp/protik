@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">               

                <div class="card-header bg-success">
            Mamber List

          </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif


                    
<table class="table table-bordered">
  <thead>
    <tr>
      <th>ID No.</th>
      <th>Name</th>
      <th>Village</th>
      <th>SSC Passing Year</th>
      <th>Mobile Number</th>
      <th>Action</th>                
    </tr>
  </thead>
  <tbody>
    @foreach($all_mambers as $mamber)
 
        <tr>
          <td>{{$mamber->id}}</td>     
          <td>{{$mamber->name}}</td>
          <td>{{$mamber->village}}</td>
          <td>{{$mamber->ssc_passing_year}}</td>
          <td>{{$mamber->mobile_number}}</td>
          </tr>    
    @endforeach
  </tbody>
</table>              


                       
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
