@extends('layouts/app')


@section('content')

<div class="container">
        
                    <div class="card-header">
                        <h1 align="center"> Bhanor N.H High School EX-Student Forum</h1>          </div>
            <div class="card-body"> 
                                       
                  

         <h3 align="center">  
আপনি কী ভানোর এন.এইচ উচ্চ বিদ্যালয়ের প্রাক্তন ছাত্র-ছাত্রী। তাহলে আমরা আপনাকেই খুঁজছি। আপনি অতি দ্রুত আমাদের সাথে যুক্ত হোন। আমাদের সাথে যুক্ত হওয়ার জন্য Registration ক্লিক করে ফরম সাবমিট করুন। 

</h3>
       

<button type="submit" class="btn btn-primary"><a href="{{ url('/about') }}"> <font color="white">About</font> </a></button>

<button type="submit" class="btn btn-primary"><a href="{{ url('/contact') }}"> <font color="white">Contact</font> </a></button>

<button type="submit" class="btn btn-primary"><a href="{{ url('/notice') }}"> <font color="white">Notice</font> </a></button>

<button type="submit" class="btn btn-primary"><a href="{{ url('/add/mamber/view') }}"><font color="white">Registration</font></a></button>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

 <div class="card-header bg-success">
                        নিমানে ভানোর এন.এইচ উচ্চ বিদ্যালয় এস.এস.সি ২০১৬ ব্যাচ

                    </div>



@endsection