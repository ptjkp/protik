<!DOCTYPE html>
<html lang="en">
<style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
<head>

	<meta charset="UTF-8">
	<title>contact</title>
</head>
<body>
	
	<br>
								<br>
								<br>

<h1> Mostafizur Rahman <br> ssc_passing_year: 2009 <br> Mobile: 01799382209 </h1>
<h1 align="center"> Asaduzzaman Asad <br> ssc_passing_year: 2016 <br> Mobile: 01756986981, 01974006828 </h1>
<h1> Md. Kamal Hossen <br> ssc_passing_year: 2016 <br> Mobile: 01752244351, 01559691419 </h1>
<h1 align="center"> Md. Altafur Rahman <br> ssc_passing_year: 2016 <br> Mobile: 01762935610,  </h1>
</body>
</html>



								