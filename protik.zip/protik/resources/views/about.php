<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>About</title>
</head>
<body>
	<br>
	<br>
	<br>
	<h3 align="center"> ভানোর এন.এইচ উচ্চ বিদ্যালয়ের সকল প্রাক্তন ছাত্র-ছাত্রী নিয়ে গঠিত হয় ভানোর এন.এইচ প্রাক্ত ছাত্রা-ছাত্রী ফোরাম। এই ফোরামের উদ্দেশ্য নিজ এলাকার শিক্ষার মান উন্নয়ন করা। </h3>
</body>
</html>