@extends('layouts/app')


@section('content')
	<div class="container">
		<div class="row">

			<div class="col-6 offset-3">
				<div class="card">

					<div class="card-header bg-success">
						Registration Form

					</div>
							<div class="card-body">
							@if (session('status'))
							<div class="alert alert-success">
								{{session('status')}}

							</div>
							@endif
<form action="{{ url('add/mamber/insert') }}" method="post">
@csrf
<div class="form-group">
<label>Name</label>
<input type="text" class="form-control"  placeholder="Enter Your Name" name="name">
</div>



<div class="form-group">
    <label>Gender</label>
    <select type="text" class="form-control"  placeholder="Enter Your Gender" name="gender">
    	<option selected>---Select---</option>
      <option>Female</option>
      <option>Male</option>
      
    </select>
  </div>

			<div class="form-group">
			<label>Marital Status</label>			
			<select type="text" class="form-control"  placeholder="Enter Your Gender" name="marital_status">
    	<option selected>---Select---</option>
      <option>Married</option>
      <option>Unmarried</option>  
      
    </select>
			</div>
			<div class="form-group">
			<label>Village</label>
			<input type="text" class="form-control"  placeholder="Enter Your Village" name="village">
			</div>

			

			<div class="form-group">
			<label>SSC Passing Year</label>
			<select type="text" class="form-control"  placeholder="Enter Your Gender" name="ssc_passing_year">
    	<option selected>---Select---</option>
      <option>2019</option> <option>2018</option><option>2017</option><option>2016</option><option>2015</option><option>2014</option><option>2013</option><option>2012</option><option>2011</option><option>2010</option><option>2009</option><option>2008</option><option>2007</option><option>2006</option><option>2005</option><option>2004</option><option>2003</option><option>2002</option><option>2001</option><option>2000</option><option>1999</option><option>1998</option><option>1997</option><option>1996</option><option>1995</option><option>1994</option><option>1993</option><option>1992</option><option>1991</option><option>1990</option><option>1989</option><option>1988</option><option>1987</option><option>1986</option><option>1985</option><option>1984</option><option>1983</option><option>1982</option><option>1981</option><option>1980</option><option>1979</option><option>1978</option><option>1977</option><option>1976</option><option>1975</option><option>1974</option><option>1973</option><option>1972</option>
    </select>
			</div>
			<div class="form-group">
			<label>Mobile Number</label>
			<input type="text" class="form-control"  placeholder="Enter Your Mobile Number" name="mobile_number">
			</div>




<button type="submit" class="btn btn-primary">Submit</button>
</form>

					</div>
				</div>
			</div>
		</div>

	</div>
@endsection
