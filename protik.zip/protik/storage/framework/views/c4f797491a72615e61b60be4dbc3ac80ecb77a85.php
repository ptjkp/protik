<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">               

                <div class="card-header bg-success">
            Mamber List

          </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    
<table class="table table-bordered">
  <thead>
    <tr>
      <th>ID No.</th>
      <th>Name</th>
      <th>Village</th>
      <th>SSC Passing Year</th>
      <th>Mobile Number</th>
      <th>Action</th>                
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $all_mambers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mamber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
        <tr>
          <td><?php echo e($mamber->id); ?></td>     
          <td><?php echo e($mamber->name); ?></td>
          <td><?php echo e($mamber->village); ?></td>
          <td><?php echo e($mamber->ssc_passing_year); ?></td>
          <td><?php echo e($mamber->mobile_number); ?></td>
          </tr>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>              


                       
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Imran\Desktop\protik\resources\views/home.blade.php ENDPATH**/ ?>