<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mamber;
class MamberController extends Controller
{
    function addmamberview ()
    {
    return view ('mamber/view');
    }

        function addmamberinsert (Request $request)
    {
       Mamber::insert([
         'name' => $request->name,
         'gender' => $request->gender,
         'marital_status' => $request->marital_status,
         'village' => $request->village,         
         'ssc_passing_year' => $request->ssc_passing_year,
         'mobile_number' => $request->mobile_number,
       ]);
      return back ()-> with('status','Submit Successfully!');        
        }

}
