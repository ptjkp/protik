<?php echo e($slot); ?>

<?php /**PATH C:\Users\Imran\Desktop\protik\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>