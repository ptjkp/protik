<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">

			<div class="col-6 offset-3">
				<div class="card">

					<div class="card-header bg-success">
						Add Mamber Forme

					</div>
							<div class="card-body">
							<?php if(session('status')): ?>
							<div class="alert alert-success">
								<?php echo e(session('status')); ?>


							</div>
							<?php endif; ?>
<form action="<?php echo e(url('add/mamber/insert')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="form-group">
<label>Name</label>
<input type="text" class="form-control"  placeholder="Enter Your Name" name="name">
</div>
<div class="form-group">
			<label>Gender</label>
			<input type="text" class="form-control"  placeholder="Enter Your Gender" name="gender">
			</div>
			<div class="form-group">
			<label>Marital Status</label>
			<input type="text" class="form-control"  placeholder="Enter Your Marital Status" name="marital_status">
			</div>
			<div class="form-group">
			<label>Village</label>
			<input type="text" class="form-control"  placeholder="Enter Your Village" name="village">
			</div>

			<div class="form-group">
			<label>District</label>
			<input type="text" class="form-control"  placeholder="Enter Your District" name="district">
			</div>

			<div class="form-group">
			<label>Upazila</label>
			<input type="text" class="form-control"  placeholder="Enter Your Upazila" name="upazila">
			</div>
			<div class="form-group">
			<label>Post Office</label>
			<input type="text" class="form-control"  placeholder="Enter Your Post Office" name="post_office">
			</div>

			<div class="form-group">
			<label>SSC Passing Year</label>
			<input type="text" class="form-control"  placeholder="Enter Your SSC Passing Year" name="ssc_passing_year">
			</div>
			<div class="form-group">
			<label>Mobile Number</label>
			<input type="text" class="form-control"  placeholder="Enter Your Mobile Number" name="mobile_number">
			</div>




<button type="submit" class="btn btn-primary">Submit</button>
</form>

					</div>
				</div>
			</div>
		</div>

	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Imran\Desktop\protik\resources\views/mamber/view.blade.php ENDPATH**/ ?>